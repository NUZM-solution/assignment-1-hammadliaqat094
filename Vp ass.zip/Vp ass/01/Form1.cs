using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VP_assignment_2_01_
{
    public partial class LoginForm : Form
    {
        Double count = 0;
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogin;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtuser_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = "Hammad Liaqat";
            pass = "22011556-094";

            if (txtuser.Text == user && txtpass.Text == pass)
            {
                MessageBox.Show("Welcome User");
            }
            else
            {
                count += 1; // Increment count by 1
                double maxCount = 5;
                double remain = maxCount - count;

                MessageBox.Show($"Wrong Username or Password. You have {remain} tries left.");

                txtpass.Clear();
                txtuser.Clear();
                txtuser.Focus();

                if (count >= maxCount) // Check if count has reached or exceeded maxCount
                {
                    MessageBox.Show("Max tries reached");
                    Application.Exit();
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtpass.Text = "";
            txtpass.Text = string .Empty;
            txtpass.Clear();
            txtuser.Clear();
            txtuser.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
