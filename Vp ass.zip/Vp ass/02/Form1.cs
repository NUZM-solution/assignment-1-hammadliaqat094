using System.Data;

namespace VP_assignment_0002
{
    public partial class Form1 : Form
    {

        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void createnewrow()
        {
            if (dt.Rows.Count <= 0)
            {

                DataColumn dc1 = new DataColumn("COURSE CODE", typeof(string));
                DataColumn dc2 = new DataColumn("COURSE TITLE", typeof(string));
                DataColumn dc3 = new DataColumn("OBTAINED MARKS", typeof(int));
                DataColumn dc4 = new DataColumn("GRADE", typeof(string));
                DataColumn dc5 = new DataColumn("STATUS", typeof(string));



                dt.Columns.Add(dc1);
                dt.Columns.Add(dc2);
                dt.Columns.Add(dc3);
                dt.Columns.Add(dc4);
                dt.Columns.Add(dc5);




                dt.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);


                dataGridView1.DataSource = dt;

            }
            else
            {

                dt.Rows.Add(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, textBox5.Text);


                dataGridView1.DataSource = dt;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            createnewrow();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
